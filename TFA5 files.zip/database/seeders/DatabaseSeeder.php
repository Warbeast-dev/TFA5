<?php
namespace Database\Seeders;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\UserController;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // The activity keeps its canonical sample arrays in the controllers.
        $datasets = [
            'customers' => (new CustomerController)->index()->getData()['customers'],
            'users' => (new UserController)->index()->getData()['users'],
        ];
        foreach ($datasets as $table => $records) {
            foreach ($records as $record) {
                DB::table($table)->updateOrInsert(['account_id' => $record['account_id']], $record);
            }
        }
    }
}
