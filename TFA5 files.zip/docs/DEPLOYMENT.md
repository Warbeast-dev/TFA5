# InfinityFree deployment

## Use the prepared archive

Run `PREPARE-INFINITYFREE.ps1` on Windows with PHP 8.3+ and Composer first. Only its successful output, `build-output/INFINITYFREE-UPLOAD.zip`, contains installed dependencies and an application key. The original source ZIP does not run as uploaded.

1. In InfinityFree, choose your hosting account and the intended domain. Locate that domain's `htdocs` folder; an addon domain can have its own folder.
2. Extract the prepared upload ZIP on your computer. Connect with the FTP credentials from your InfinityFree account. Upload the extracted contents into `htdocs`, including `.env`, root `.htaccess`, `public/.htaccess`, all of `vendor/`, and empty storage/cache folders. Do not upload the ZIP alone. FTP avoids relying on a file manager to extract a large archive.
3. Preserve any unrelated site files by backing them up first. If this is a fresh site, remove its default placeholder index HTML file when it interferes with the application.
4. Confirm `htdocs/artisan`, `htdocs/vendor/autoload.php` and `htdocs/public/index.php` exist. Do not nest the project under another folder.
5. Ensure `storage/` and `bootstrap/cache/` are writable by PHP. Keep standard host permissions unless an actual permission error appears; do not blindly set everything to 777.
6. Visit the domain and all three other routes. No MySQL credentials or migrations are needed for these static listings.

The root rewrite routes requests through `public` while denying direct requests to private application paths and dotfiles. The normal public front controller remains in place. Do not remove either `.htaccess` file or move `.env` into `public`.

## Live checks

- `/`, `/about`, `/customers`, `/users` load successfully and link to each other.
- Both tables display five records. At phone width the navigation wraps and tables scroll horizontally.
- `/css/app.css` loads as CSS, not an HTML error page.
- `/not-a-page` returns a 404 page.
- `/.env`, `/composer.json`, `/storage/logs/laravel.log` and `/vendor/autoload.php` return 403 or 404 and never disclose their contents.
- `APP_DEBUG=false`, `APP_ENV=production`, and `APP_URL` matches the domain.
- Confirm HTTPS works before using an HTTPS APP_URL or forcing secure cookies.

## Troubleshooting

**Missing vendor/autoload.php:** The source ZIP was uploaded, or FTP skipped dependencies. Run the preparation script and upload the generated output completely.

**500 response:** Review `storage/logs/laravel.log` through the file manager/FTP privately. Verify the PHP version, required extensions, APP_KEY and write permissions. Verify both htaccess files uploaded. If no Laravel log is created, check the host's PHP/Apache error information. Do not enable public debug output to expose server details.

**Home works but other routes do not:** Confirm both `.htaccess` files are present and the project contents sit directly inside the correct domain's `htdocs`.

**Old placeholders or wrong website:** Check the domain's correct document root and any default index HTML file.

**Missing class after an apparently successful upload:** Recheck the failed FTP transfer queue and compare vendor files. The builder checks PHP files against a conservative 1,000,000-byte limit because InfinityFree documents a PHP file size limit. Do not solve missing classes by deleting framework source.

**Stale paths after moving the app:** Remove generated PHP cache files from `bootstrap/cache` and compiled views from `storage/framework/views`; retain the directories and `.gitignore` files. The preparation script already clears these in the upload staging copy.

**Composer errors:** Resolve the exact PHP version/extension/network message on your computer. Never use `--ignore-platform-reqs` to force an incompatible installation.

InfinityFree does not provide a terminal for Composer/Artisan; preparation happens locally. Its official deployment guidance explains the htdocs restriction and installed-vendor requirement: https://forum.infinityfree.com/t/how-to-install-a-laravel-site-on-infinityfree/118578
