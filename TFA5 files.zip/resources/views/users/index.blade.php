@extends('layouts.app')
@section('title', 'User Accounts')
@section('content')
<section class="page-heading">
    <p class="eyebrow">PEOPLE / TEAM</p>
    <h1>User Accounts</h1>
    <p class="lead">Your store team, assigned roles and account status.</p>
</section>
<section class="table-panel" aria-labelledby="directory-title">
    <div class="table-heading">
        <div>
            <h2 id="directory-title">All users</h2>
            <p>Fictional records for this classroom demonstration.</p>
        </div><span class="count">{{ count($users) }} records</span>
    </div>
    <div class="table-scroll" role="region" aria-label="User account records" tabindex="0">
        <table>
            <caption class="sr-only">User account directory</caption>
            <thead>
                <tr>
                    <th scope="col">Account ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $user)
                <tr>
                    <td>{{ $user['account_id'] }}</td>
                    <td>{{ $user['name'] }}</td>
                    <td>{{ $user['email'] }}</td>
                    <td>{{ $user['role'] }}</td>
                    <td><span class="status {{ $user['status'] === 'Active' ? 'active' : 'inactive' }}">{{ $user['status'] }}</span></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</section>
<p class="note">Read-only account listing</p>
@endsection