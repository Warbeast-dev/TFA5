@extends('layouts.app')
@section('title', 'Customer Accounts')
@section('content')
<section class="page-heading">
    <p class="eyebrow">PEOPLE / DIRECTORY</p>
    <h1>Customer Accounts</h1>
    <p class="lead">Customer contact details, locations and account status.</p>
</section>
<section class="table-panel" aria-labelledby="directory-title">
    <div class="table-heading">
        <div>
            <h2 id="directory-title">All customers</h2>
            <p>Fictional records for this classroom demonstration.</p>
        </div><span class="count">{{ count($customers) }} records</span>
    </div>
    <div class="table-scroll" role="region" aria-label="Customer account records" tabindex="0">
        <table>
            <caption class="sr-only">Customer account directory</caption>
            <thead>
                <tr>
                    <th scope="col">Account ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">City</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($customers as $customer)
                <tr>
                    <td>{{ $customer['account_id'] }}</td>
                    <td>{{ $customer['name'] }}</td>
                    <td>{{ $customer['email'] }}</td>
                    <td>{{ $customer['phone'] }}</td>
                    <td>{{ $customer['city'] }}</td>
                    <td><span class="status {{ $customer['status'] === 'Active' ? 'active' : 'inactive' }}">{{ $customer['status'] }}</span></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</section>
<p class="note">Read-only account listing</p>
@endsection