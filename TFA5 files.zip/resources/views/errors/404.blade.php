@extends('layouts.app')
@section('title', 'Page not found')
@section('content')
<section class="page-heading">
    <p class="eyebrow">404</p>
    <h1>Page not found</h1>
    <p class="lead">That address is not part of this workspace.</p><a class="button" href="{{ route('home') }}">Back to home</a>
</section>
@endsection