<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="POS Foundations — Laravel customer and user account directory.">
    <title>@yield('title') | POS Foundations</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>

<body>
    <a class="skip" href="#main">Skip to content</a>
    <header class="site-header">
        <div class="nav-wrap">
            <a class="brand" href="{{ route('home') }}"><span class="brand-mark" aria-hidden="true">P</span><span>POS<span class="brand-light"> Foundations</span></span></a>
            <nav aria-label="Main navigation">
                <a href="{{ route('home') }}" @if(request()->routeIs('home')) aria-current="page" @endif>Home</a>
                <a href="{{ route('about') }}" @if(request()->routeIs('about')) aria-current="page" @endif>About</a>
                <a href="{{ route('customers.index') }}" @if(request()->routeIs('customers.index')) aria-current="page" @endif>Customers</a>
                <a href="{{ route('users.index') }}" @if(request()->routeIs('users.index')) aria-current="page" @endif>Users</a>
            </nav>
        </div>
    </header>
    <main id="main" class="container">@yield('content')</main>
    <footer class="container"><span>POS Foundations</span><span>IT0049 · TFA5 · Laravel MVC</span></footer>
</body>

</html>