<?php $__env->startSection('title', 'User Accounts'); ?>
<?php $__env->startSection('content'); ?>
<section class="page-heading">
    <p class="eyebrow">PEOPLE / TEAM</p>
    <h1>User Accounts</h1>
    <p class="lead">Your store team, assigned roles and account status.</p>
</section>
<section class="table-panel" aria-labelledby="directory-title">
    <div class="table-heading">
        <div>
            <h2 id="directory-title">All users</h2>
            <p>Fictional records for this classroom demonstration.</p>
        </div><span class="count"><?php echo e(count($users)); ?> records</span>
    </div>
    <div class="table-scroll" role="region" aria-label="User account records" tabindex="0">
        <table>
            <caption class="sr-only">User account directory</caption>
            <thead>
                <tr>
                    <th scope="col">Account ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user['account_id']); ?></td>
                    <td><?php echo e($user['name']); ?></td>
                    <td><?php echo e($user['email']); ?></td>
                    <td><?php echo e($user['role']); ?></td>
                    <td><span class="status <?php echo e($user['status'] === 'Active' ? 'active' : 'inactive'); ?>"><?php echo e($user['status']); ?></span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<p class="note">Read-only account listing</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\glenn\Downloads\POS-Foundations-SOURCE-with-Windows-Builder\POS-Foundations\resources\views/users/index.blade.php ENDPATH**/ ?>