<?php $__env->startSection('title', 'Page not found'); ?>
<?php $__env->startSection('content'); ?>
<section class="page-heading">
    <p class="eyebrow">404</p>
    <h1>Page not found</h1>
    <p class="lead">That address is not part of this workspace.</p><a class="button" href="<?php echo e(route('home')); ?>">Back to home</a>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\glenn\Downloads\POS-Foundations-SOURCE-with-Windows-Builder\POS-Foundations\resources\views/errors/404.blade.php ENDPATH**/ ?>