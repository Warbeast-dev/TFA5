<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('content'); ?>
<section class="page-heading">
    <p class="eyebrow">THE PROJECT</p>
    <h1>About POS Foundations</h1>
    <p class="lead">Four connected pages. One foundation for a point-of-sale application.</p>
</section>
<div class="about-grid">
    <section>
        <h2>Built for the fundamentals</h2>
        <p>This application completes “From Zero to Four Pages, Again: My First Laravel Application.” It rebuilds the POS page structure using Laravel routes, controllers and Blade templates.</p>
        <p>Customers and users are displayed from static PHP arrays.</p>
        <h2>How the pages work</h2>
        <ol class="steps">
            <li><strong>Routes choose the destination.</strong> Each URL maps to a controller method.</li>
            <li><strong>Controllers prepare the response.</strong> Account controllers provide five fictional records each.</li>
            <li><strong>Blade presents the information.</strong> Shared navigation connects all pages, and loops display the account records.</li>
        </ol>
    </section>
    <aside class="info-panel">
        <p class="eyebrow">ACTIVITY DETAILS</p>
        <dl>
            <dt>Course</dt>
            <dd><?php echo e($course); ?></dd>
            <dt>Assessment</dt>
            <dd>Technical Formative Assessment 5</dd>
            <dt>Scope</dt>
            <dd>Landing, About, Customer Accounts and User Accounts</dd>
        </dl>
        <p class="note">POS Foundations</p>
    </aside>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\glenn\Downloads\POS-Foundations-SOURCE-with-Windows-Builder\POS-Foundations\resources\views/about.blade.php ENDPATH**/ ?>