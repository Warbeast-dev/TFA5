<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="POS Foundations — Laravel customer and user account directory.">
    <title><?php echo $__env->yieldContent('title'); ?> | POS Foundations</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>
    <a class="skip" href="#main">Skip to content</a>
    <header class="site-header">
        <div class="nav-wrap">
            <a class="brand" href="<?php echo e(route('home')); ?>"><span class="brand-mark" aria-hidden="true">P</span><span>POS<span class="brand-light"> Foundations</span></span></a>
            <nav aria-label="Main navigation">
                <a href="<?php echo e(route('home')); ?>" <?php if (request()->routeIs('home')): ?> aria-current="page" <?php endif; ?>>Home</a>
                <a href="<?php echo e(route('about')); ?>" <?php if (request()->routeIs('about')): ?> aria-current="page" <?php endif; ?>>About</a>
                <a href="<?php echo e(route('customers.index')); ?>" <?php if (request()->routeIs('customers.index')): ?> aria-current="page" <?php endif; ?>>Customers</a>
                <a href="<?php echo e(route('users.index')); ?>" <?php if (request()->routeIs('users.index')): ?> aria-current="page" <?php endif; ?>>Users</a>
            </nav>
        </div>
    </header>
    <main id="main" class="container"><?php echo $__env->yieldContent('content'); ?></main>
    <footer class="container"><span>POS Foundations</span><span>IT0049 · TFA5 · Laravel MVC</span></footer>
</body>

</html>
<?php /**PATH C:\Users\glenn\Downloads\POS-Foundations-SOURCE-with-Windows-Builder\POS-Foundations\resources\views/layouts/app.blade.php ENDPATH**/ ?>