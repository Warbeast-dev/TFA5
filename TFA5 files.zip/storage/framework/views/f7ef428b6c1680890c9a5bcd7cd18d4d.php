<?php $__env->startSection('title', 'Customer Accounts'); ?>
<?php $__env->startSection('content'); ?>
<section class="page-heading">
    <p class="eyebrow">PEOPLE / DIRECTORY</p>
    <h1>Customer Accounts</h1>
    <p class="lead">Customer contact details, locations and account status.</p>
</section>
<section class="table-panel" aria-labelledby="directory-title">
    <div class="table-heading">
        <div>
            <h2 id="directory-title">All customers</h2>
            <p>Fictional records for this classroom demonstration.</p>
        </div><span class="count"><?php echo e(count($customers)); ?> records</span>
    </div>
    <div class="table-scroll" role="region" aria-label="Customer account records" tabindex="0">
        <table>
            <caption class="sr-only">Customer account directory</caption>
            <thead>
                <tr>
                    <th scope="col">Account ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">City</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($customer['account_id']); ?></td>
                    <td><?php echo e($customer['name']); ?></td>
                    <td><?php echo e($customer['email']); ?></td>
                    <td><?php echo e($customer['phone']); ?></td>
                    <td><?php echo e($customer['city']); ?></td>
                    <td><span class="status <?php echo e($customer['status'] === 'Active' ? 'active' : 'inactive'); ?>"><?php echo e($customer['status']); ?></span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<p class="note">Read-only account listing</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\glenn\Downloads\POS-Foundations-SOURCE-with-Windows-Builder\POS-Foundations\resources\views/customers/index.blade.php ENDPATH**/ ?>