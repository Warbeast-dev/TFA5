<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<section class="hero">
    <div>
        <p class="eyebrow">YOUR BUSINESS, ORGANIZED</p>
        <h1>A clear view of<br>the people behind<br><em>every transaction.</em></h1>
        <p class="lead">Welcome to POS Foundations. Explore your customer directory and store team in one simple workspace.</p>
        <div class="actions"><a class="button" href="<?php echo e(route('customers.index')); ?>">View customers <span aria-hidden="true">↗</span></a><a class="text-link" href="<?php echo e(route('about')); ?>">About this project →</a></div>
    </div>
    <aside class="overview" aria-label="Project overview"><span class="pill">POS FOUNDATIONS</span>
        <h2>Good service starts<br>with good records.</h2>
        <p>A simple starting point for an organized store.</p>
        <div class="overview-row"><span>01</span>
            <div><strong>Customer Accounts</strong><small>Contact details and account status</small></div>
        </div>
        <div class="overview-row"><span>02</span>
            <div><strong>User Accounts</strong><small>Store team, roles and account status</small></div>
        </div>
    </aside>
</section>
<section class="section">
    <p class="eyebrow">EXPLORE YOUR WORKSPACE</p>
    <div class="cards">
        <a class="card" href="<?php echo e(route('customers.index')); ?>"><span class="card-no">01 / DIRECTORY</span>
            <h2>Customer Accounts <span>↗</span></h2>
            <p>Find customer contact information and review account status.</p>
        </a>
        <a class="card" href="<?php echo e(route('users.index')); ?>"><span class="card-no">02 / TEAM</span>
            <h2>User Accounts <span>↗</span></h2>
            <p>Get a clear overview of store users and their assigned roles.</p>
        </a>
    </div>
</section>
<p class="note">All account records are fictional sample data.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\glenn\Downloads\POS-Foundations-SOURCE-with-Windows-Builder\POS-Foundations\resources\views/home.blade.php ENDPATH**/ ?>