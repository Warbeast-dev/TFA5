<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class CustomerController extends Controller
{
    public function index(): View
    {

        $customers = [
            ['account_id' => 'CUS-001', 'name' => 'Ana Santos', 'email' => 'ana.santos@example.com', 'phone' => '0917 000 0101', 'city' => 'Quezon City', 'status' => 'Active'],
            ['account_id' => 'CUS-002', 'name' => 'Miguel Reyes', 'email' => 'miguel.reyes@example.com', 'phone' => '0917 000 0102', 'city' => 'Manila', 'status' => 'Active'],
            ['account_id' => 'CUS-003', 'name' => 'Bea Cruz', 'email' => 'bea.cruz@example.com', 'phone' => '0917 000 0103', 'city' => 'Makati', 'status' => 'Active'],
            ['account_id' => 'CUS-004', 'name' => 'Paolo Garcia', 'email' => 'paolo.garcia@example.com', 'phone' => '0917 000 0104', 'city' => 'Pasig', 'status' => 'Inactive'],
            ['account_id' => 'CUS-005', 'name' => 'Sofia Ramos', 'email' => 'sofia.ramos@example.com', 'phone' => '0917 000 0105', 'city' => 'Taguig', 'status' => 'Active'],
        ];
        return view('customers.index', compact('customers'));
    }
}
