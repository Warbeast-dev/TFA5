<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class UserController extends Controller
{
    public function index(): View
    {
        
        $users = [
            ['account_id' => 'USR-001', 'name' => 'Alex Mendoza', 'email' => 'alex.mendoza@example.com', 'role' => 'Administrator', 'status' => 'Active'],
            ['account_id' => 'USR-002', 'name' => 'Jamie Torres', 'email' => 'jamie.torres@example.com', 'role' => 'Manager', 'status' => 'Active'],
            ['account_id' => 'USR-003', 'name' => 'Sam Flores', 'email' => 'sam.flores@example.com', 'role' => 'Cashier', 'status' => 'Active'],
            ['account_id' => 'USR-004', 'name' => 'Riley Navarro', 'email' => 'riley.navarro@example.com', 'role' => 'Inventory Staff', 'status' => 'Active'],
            ['account_id' => 'USR-005', 'name' => 'Casey Lim', 'email' => 'casey.lim@example.com', 'role' => 'Cashier', 'status' => 'Inactive'],
        ];
        return view('users.index', compact('users'));
    }
}
