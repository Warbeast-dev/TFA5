<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class PageController extends Controller
{
    public function index(): View
    {
        return view('home');
    }
    public function about(): View
    {
        return view('about', ['course' => 'IT0049 — Web System Technologies', 'module' => 'Module 5 — Laravel Foundations']);
    }
}
