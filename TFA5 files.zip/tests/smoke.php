<?php
require __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$failures = [];
$pages = ['/' => 'Home', '/about' => 'About POS Foundations', '/customers' => 'Customer Accounts', '/users' => 'User Accounts'];
foreach ($pages as $path => $text) {
    $request = Illuminate\Http\Request::create('http://localhost' . $path, 'GET');
    $response = $kernel->handle($request);
    $html = $response->getContent();
    if ($response->getStatusCode() !== 200 || !str_contains($html, $text)) $failures[] = "$path: status or content failed";
    foreach (['/', '/about', '/customers', '/users'] as $link) {
        if (!str_contains($html, 'href="' . rtrim('http://localhost' . $link, '/') . '"') && !str_contains($html, 'href="http://localhost' . $link . '"')) $failures[] = "$path: missing navigation $link";
    }
    if (in_array($path, ['/customers', '/users'], true)) {
        if (substr_count($html, '<tr>') !== 6) $failures[] = "$path: expected header plus five rows";
    }
    $kernel->terminate($request, $response);
}
$request = Illuminate\Http\Request::create('http://localhost/not-a-page', 'GET');
$response = $kernel->handle($request);
if ($response->getStatusCode() !== 404) $failures[] = 'Unknown URL did not return 404';
$kernel->terminate($request, $response);
foreach (['customers' => App\Http\Controllers\CustomerController::class, 'users' => App\Http\Controllers\UserController::class] as $key => $controller) {
    $view = (new $controller)->index();
    $data = $view->getData();
    if (count($data[$key]) < 5) $failures[] = "$key: fewer than five records";
    $data[$key][0]['name'] = '<script>alert(1)</script>';
    $html = view($key . '.index', $data)->render();
    if (str_contains($html, '<script>alert(1)</script>') || !str_contains($html, '&lt;script&gt;')) $failures[] = "$key: Blade escaping failed";
}
if ($failures) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}
echo "PASS: four routes, navigation, five rows per listing, 404 and Blade escaping." . PHP_EOL;
